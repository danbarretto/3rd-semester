	#include <stdio.h>

	void binarioNaTela1(FILE *ponteiroArquivoBinario);
	void binarioNaTela2(char *nomeArquivoBinario);
	void trim(char *str);
	void scan_quote_string(char *str);

