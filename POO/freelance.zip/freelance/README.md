# freelance
ATENÇÃO AO CRIAR USUÁRIO NO SCRIPT SQL
CRIAR USUÁRIO APENAS 1 VEZ
Projeto feito por (% de trabalho)
Daniel Sá Barretto Prado Garcia (50%)
Lucas Xavier Leite (50%)
